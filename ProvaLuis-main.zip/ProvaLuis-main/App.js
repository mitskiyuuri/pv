import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import * as LocalAuthentication from 'expo-local-authentication';
import { useState, useEffect } from 'react';

import {
  View,
  Text,
  Button,
  StyleSheet,
  StatusBar,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import Login from './components/Login';
import Cadastro from './components/Cadastro';
import Inicio from './components/Inicio';
import Pesquisar from './components/pesquisar';

import { initDB } from './database';

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

function MenuDrawer() {
  return (
    <>
      <StatusBar
        barStyle="light-content"
        backgroundColor="#111"
      />

      <Drawer.Navigator
        initialRouteName="InicioTela"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#111',
          },
          headerTintColor: '#E50914',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
          drawerStyle: {
            backgroundColor: '#151515',
            width: 260,
          },
          drawerActiveTintColor: '#E50914',
          drawerInactiveTintColor: '#ffffff',
          drawerLabelStyle: {
            fontSize: 16,
            fontWeight: '600',
          },
        }}
      >
        {/* Alterei o name interno para "InicioTela" para evitar conflito com o nome do grupo */}
        <Drawer.Screen
          name="InicioTela"
          component={Inicio}
          options={{
            title: 'Início',
            drawerIcon: ({ color, size }) => (
              <Ionicons
                name="film-outline"
                color={color}
                size={size}
              />
            ),
          }}
        />

        <Drawer.Screen
          name="Pesquisar"
          component={Pesquisar}
          options={{
            drawerIcon: ({ color, size }) => (
              <Ionicons
                name="search-outline"
                color={color}
                size={size}
              />
            ),
          }}
        />
      </Drawer.Navigator>
    </>
  );
}

export default function App() {
  const [status, setStatus] = useState('');
  const [autenticado, setAutenticado] = useState(false);

  useEffect(() => {
    initDB();
  }, []);

  const handleAuth = async () => {
    const hasHardware = await LocalAuthentication.hasHardwareAsync();

    if (!hasHardware) {
      setStatus('Dispositivo não suporta biometria.');
      return;
    }

    const isEnrolled = await LocalAuthentication.isEnrolledAsync();

    if (!isEnrolled) {
      setStatus('Nenhuma biometria cadastrada.');
      return;
    }

    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'Autentique-se para continuar',
      fallbackLabel: 'Usar senha',
      disableDeviceFallback: false,
    });

    if (result.success) {
      setStatus('✅ Autenticado com sucesso!');
      setAutenticado(true);
    } else {
      setStatus(`❌ Erro: ${result.error}`);
    }
  };

  if (!autenticado) {
    return (
      <View style={styles.centralizar}>
        <Text style={styles.textoStatus}>
          {status}
        </Text>

        <Button
          title="Autenticar"
          onPress={handleAuth}
        />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen
          name="Login"
          component={Login}
        />

        <Stack.Screen
          name="Cadastro"
          component={Cadastro}
        />

        {/* MUDANÇA AQUI: O nome passou a ser "Inicio". 
            Assim o comando navigation.replace('Inicio') vindo do Login vai funcionar! */}
        <Stack.Screen
          name="Inicio"
          component={MenuDrawer}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  centralizar: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0f0f0f',
    padding: 20,
  },
  textoStatus: {
    color: '#ffffff',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
});